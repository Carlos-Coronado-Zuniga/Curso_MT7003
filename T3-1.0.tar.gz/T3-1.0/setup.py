from setuptools import setup

setup(

        name="T3",
        version="1.0",
        description="Paquete que permite obtener los métodos solicitados "
        "en la tarea 3 del curso de microprocesadores y microcontroladores",
        author="Carlos, Joseph, Emmanuel y Adrian",
        packages=["Metodos"],
        python_requires='>=3',
        install_requires=['pillow','opencv','tabulate','playsound','PIL','sys','cv2','numpy']

    # When your source code is in a subdirectory under the project root, e.g.
    # `src/`, it is necessary to specify the `package_dir` argument.
    #package_dir={'': 'src'},  # Optional

    # You can just specify package directories manually here if your project is
    # simple. Or you can use find_packages().
    #
    # Alternatively, if you just want to distribute a single Python file, use
    # the `py_modules` argument instead as follows, which will expect a file
    # called `my_module.py` to exist:
    #
    #   py_modules=["my_module"],
    #
    #packages=find_packages(where='src'),  # Required

    )
